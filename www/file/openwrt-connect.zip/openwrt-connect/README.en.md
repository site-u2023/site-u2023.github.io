# OpenWrt Connect

A launcher tool that connects from Windows to OpenWrt via SSH and executes commands.

## Architecture

```
openwrt-connect.exe              openwrt-connect.conf
(Generic Core)                   (Specific Configuration)
┌─────────────────────┐          ┌──────────────────────────┐
│ ■ IPv4 Gateway       │          │ [general]                │
│   Auto-detection     │  ←────  │ product_name, default_ip │
│ ■ SSH Key Auth       │          │ ssh_user, ssh_key_prefix │
│   Auto-setup         │          │                          │
│   dropbear/openssh   │          │ [command.aios2]          │
│   Auto-compatible    │          │ url, dir, bin, label     │
│ ■ .conf Loader       │          │                          │
│ ■ Template Expansion │          │ [command.aios]           │
│ ■ Argument Dispatch  │          │ url, dir, bin, label     │
└─────────────────────┘          │                          │
                                  │ [command.ssh]            │
                                  │ label (SSH only)         │
                                  └──────────────────────────┘
```

## Build Flow

```
openwrt-connect-build.bat
  │
  ├─ gcc: openwrt-connect.c → openwrt-connect.exe
  │
  ├─ PowerShell: openwrt-connect.conf → Product.wxs (auto-generated)
  │    generate-wxs.ps1
  │      ├─ [general] → Product name, Directory name
  │      ├─ [command.*] → Feature, Shortcuts
  │      └─ icon → Icon declarations
  │
  └─ WiX: Product.wxs → openwrt-connect.msi
       ├─ openwrt-connect.exe (bundled)
       └─ openwrt-connect.conf (bundled)
```

## Usage

| Shortcut | Argument | Behavior |
|---|---|---|
| aios2 | `aios2` | Execute script based on .conf command definition |
| aios | `aios` | Execute script based on .conf command definition |
| SSH | `ssh` | Interactive SSH session |
| | `--list` | List available commands |
| | `--help` | Show help |

## Command Definition (openwrt-connect.conf)

```ini
[general]
product_name = OpenWrt Connect
default_ip = 192.168.1.1
ssh_user = root
ssh_key_prefix = owrt-connect

[command.aios2]
label = OpenWrt Persistent Installation
icon = aios2.ico
url = https://site-u.pages.dev/www/aios2.sh
dir = /tmp/aios2
bin = /usr/bin/aios2

[command.ssh]
label = SSH Connection
icon = openwrt-connect.ico
```

| Field | Description | Required | Used In |
|---|---|---|---|
| `label` | Display name | ○ | EXE banner + MSI shortcut description |
| `icon` | Icon filename | | MSI shortcut |
| `url` | Remote script URL | For command execution | EXE template expansion |
| `dir` | Temporary directory on device | For command execution | EXE template expansion |
| `bin` | Persistent path on device | For command execution | EXE template expansion |

If `url` is empty → SSH connection only (interactive mode)

## Adding Commands

1. Add `[command.newcommand]` section to `openwrt-connect.conf`
2. Place corresponding `.ico` file (optional)
3. Run `openwrt-connect-build.bat` → Automatically reflected in EXE + MSI

## Fork Example

```ini
[general]
product_name = MyRouter

[command.mysetup]
label = My Custom Script
icon = mysetup.ico
url = https://example.com/my-script.sh
dir = /tmp/mysetup
bin = /usr/bin/mysetup

[command.ssh]
label = SSH Connection
icon = openwrt-connect.ico
```

## Build Instructions

### Required Tools

- MinGW-w64 (`C:\mingw64\bin` or on PATH)
- WiX Toolset v3.11 (only for MSI build)
- PowerShell 5.0+ (Product.wxs auto-generation)

### Steps

```
openwrt-connect-build.bat
```

## Icons

| File | Purpose | Design |
|---|---|---|
| `openwrt-connect.ico` | EXE main + SSH shortcut | Plain green BG |
| `aios.ico` | aios shortcut | ONE blue text |
| `aios2.ico` | aios2 shortcut | TWO red text |

## File List

| File | Description | Edit Target |
|---|---|---|
| `openwrt-connect.conf` | Command definitions (specific config) | ○ |
| `openwrt-connect.c` | Main source (generic core) | |
| `openwrt-connect.rc` | Resource definition | |
| `generate-wxs.ps1` | .conf → Product.wxs generator | |
| `openwrt-connect-build.bat` | Build script | |
| `Product.wxs` | **Auto-generated** (do not edit directly) | |
| `app.manifest` | UAC administrator privilege request | |
| `license.rtf` | License | |
| `*.ico` | Various icons | |
