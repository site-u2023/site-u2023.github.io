# OpenWrt Connect

Windows から OpenWrt に SSH 接続し、コマンドを投入するランチャーツール。

## アーキテクチャ

```
openwrt-connect.exe              openwrt-connect.conf
(汎用コア)                        (固有設定)
┌─────────────────────┐          ┌──────────────────────────┐
│ ■ IPv4ゲートウェイ   │          │ [general]                │
│   自動検出           │  ←────  │ product_name, default_ip │
│ ■ SSH鍵認証          │          │ ssh_user, ssh_key_prefix │
│   自動セットアップ   │          │                          │
│   dropbear/openssh   │          │ [command.aios2]          │
│   自動対応           │          │ url, dir, bin, label     │
│ ■ .conf読み込み      │          │                          │
│ ■ テンプレート展開   │          │ [command.aios]           │
│ ■ 引数ディスパッチ   │          │ url, dir, bin, label     │
└─────────────────────┘          │                          │
                                  │ [command.ssh]            │
                                  │ label (SSH only)         │
                                  └──────────────────────────┘
```

## ビルドフロー

```
openwrt-connect-build.bat
  │
  ├─ gcc: openwrt-connect.c → openwrt-connect.exe
  │
  ├─ PowerShell: openwrt-connect.conf → Product.wxs (自動生成)
  │    generate-wxs.ps1
  │      ├─ [general] → Product名, ディレクトリ名
  │      ├─ [command.*] → Feature, ショートカット
  │      └─ icon → Icon宣言
  │
  └─ WiX: Product.wxs → openwrt-connect.msi
       ├─ openwrt-connect.exe (同梱)
       └─ openwrt-connect.conf (同梱)
```

## 使い方

| ショートカット | 引数 | 動作 |
|---|---|---|
| aios2 | `aios2` | .confのコマンド定義に基づきスクリプト実行 |
| aios | `aios` | .confのコマンド定義に基づきスクリプト実行 |
| SSH | `ssh` | インタラクティブSSH |
| | `--list` | 利用可能なコマンド一覧 |
| | `--help` | ヘルプ表示 |

## コマンド定義 (openwrt-connect.conf)

```ini
[general]
product_name = OpenWrt Connect
default_ip = 192.168.1.1
ssh_user = root
ssh_key_prefix = owrt-connect

[command.aios2]
label = OpenWrt Persistent Installation
icon = aios2.ico
url = https://site-u.pages.dev/www/aios2.sh
dir = /tmp/aios2
bin = /usr/bin/aios2

[command.ssh]
label = SSH Connection
icon = openwrt-connect.ico
```

| フィールド | 説明 | 必須 | 反映先 |
|---|---|---|---|
| `label` | 表示名 | ○ | EXEバナー + MSIショートカット説明 |
| `icon` | アイコンファイル名 | | MSIショートカット |
| `url` | リモートスクリプトURL | コマンド実行時 | EXEテンプレート展開 |
| `dir` | デバイス上の一時ディレクトリ | コマンド実行時 | EXEテンプレート展開 |
| `bin` | デバイス上の永続化パス | コマンド実行時 | EXEテンプレート展開 |

`url` が空の場合 → SSH接続のみ（インタラクティブモード）

## コマンド追加手順

1. `openwrt-connect.conf` に `[command.新コマンド名]` セクション追加
2. 対応する `.ico` ファイルを配置（任意）
3. `openwrt-connect-build.bat` 実行 → EXE + MSI に自動反映

## フォーク例

```ini
[general]
product_name = MyRouter

[command.mysetup]
label = My Custom Script
icon = mysetup.ico
url = https://example.com/my-script.sh
dir = /tmp/mysetup
bin = /usr/bin/mysetup

[command.ssh]
label = SSH Connection
icon = openwrt-connect.ico
```

## ビルド方法

### 必要ツール

- MinGW-w64 (`C:\mingw64\bin` または PATH上)
- WiX Toolset v3.11 (MSIビルド時のみ)
- PowerShell 5.0+ (Product.wxs自動生成)

### 手順

```
openwrt-connect-build.bat
```

## アイコン

| ファイル | 用途 | デザイン |
|---|---|---|
| `openwrt-connect.ico` | EXE本体 + SSHショートカット | 無地 緑BG |
| `aios.ico` | aiosショートカット | ONE 青字 |
| `aios2.ico` | aios2ショートカット | TWO 赤字 |

## ファイル一覧

| ファイル | 説明 | 編集対象 |
|---|---|---|
| `openwrt-connect.conf` | コマンド定義（固有設定） | ○ |
| `openwrt-connect.c` | メインソース（汎用コア） | |
| `openwrt-connect.rc` | リソース定義 | |
| `generate-wxs.ps1` | .conf → Product.wxs 生成 | |
| `openwrt-connect-build.bat` | ビルドスクリプト | |
| `Product.wxs` | **自動生成** (直接編集不要) | |
| `app.manifest` | UAC管理者権限要求 | |
| `license.rtf` | ライセンス | |
| `*.ico` | アイコン各種 | |
