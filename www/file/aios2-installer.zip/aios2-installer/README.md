# AIOS2 Installer

## 構成

1つの `aios2.exe` で3つのモードを提供：

| ショートカット | 引数 | 動作 |
|---|---|---|
| aios2 | `https://site-u.pages.dev/www/aios2.sh` | スクリプト実行 |
| aios | `https://raw.githubusercontent.com/site-u2023/aios/main/aios` | 旧版スクリプト実行 |
| SSH | (なし) | インタラクティブSSH |

## ビルド方法

1. `aios2.ico` を同じフォルダに配置
2. `build.bat` を実行

### 必要ツール

- MinGW-w64 (`C:\mingw64\bin` または PATH上)
- WiX Toolset v3.11 (MSIビルド時のみ)

## ファイル一覧

- `aios2.c` - メインソース（統合版）
- `Product.wxs` - WiXインストーラー定義
- `build.bat` - ビルドスクリプト
- `app.manifest` - UAC管理者権限要求
- `aios2.rc` - リソース定義（アイコン＋マニフェスト）
- `license.rtf` - ライセンス
- `aios2.ico` - アイコン（別途用意）
