/*
 * aios2.exe - OpenWrt Remote Setup Tool
 *
 * Usage:
 *   aios2.exe              Interactive SSH connection
 *   aios2.exe aios2        Execute aios2 command (auto-install if needed)
 *   aios2.exe aios         Execute aios command (auto-install if needed)
 */
#define _WIN32_WINNT 0x0600
#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")

#define DEFAULT_IP    "192.168.1.1"

#define SSH_OPTS \
    " -o StrictHostKeyChecking=no" \
    " -o UserKnownHostsFile=NUL" \
    " -o GlobalKnownHostsFile=NUL" \
    " -o HostKeyAlgorithms=+ssh-rsa" \
    " -o PubkeyAcceptedKeyTypes=+ssh-rsa" \
    " -o LogLevel=ERROR"

/* ================================================== */
/* Forward declarations                               */
/* ================================================== */
int is_private_ip(const char *ip);
int get_default_gateway(char *ip, size_t size);
int detect_router_ip(char *ip, size_t size);
int file_exists(const char *path);
void get_key_paths(const char *ip, char *priv, char *pub, char *ssh_dir, size_t size);
int ensure_ssh_key(const char *sysroot, const char *key_path, const char *ssh_dir);
int test_key_auth(const char *sysroot, const char *key_path, const char *ip);
int send_public_key(const char *sysroot, const char *pub_path, const char *ip);
const char* get_aios2_installer(void);
const char* get_aios_installer(void);

/* ================================================== */
/* Network functions                                  */
/* ================================================== */
int is_private_ip(const char *ip)
{
    unsigned int b1, b2, b3, b4;
    if (sscanf(ip, "%u.%u.%u.%u", &b1, &b2, &b3, &b4) != 4) return 0;
    if (b1 == 10) return 1;
    if (b1 == 172 && b2 >= 16 && b2 <= 31) return 1;
    if (b1 == 192 && b2 == 168) return 1;
    return 0;
}

int get_default_gateway(char *ip, size_t size)
{
    PMIB_IPFORWARDTABLE pIpForwardTable = NULL;
    ULONG dwSize = 0;
    DWORD dwRetVal = 0;
    int found = 0;

    dwRetVal = GetIpForwardTable(NULL, &dwSize, 0);
    if (dwRetVal == ERROR_INSUFFICIENT_BUFFER) {
        pIpForwardTable = (MIB_IPFORWARDTABLE *)malloc(dwSize);
        if (pIpForwardTable == NULL) return 0;
    } else {
        return 0;
    }

    if (GetIpForwardTable(pIpForwardTable, &dwSize, 0) == NO_ERROR) {
        for (DWORD i = 0; i < pIpForwardTable->dwNumEntries; i++) {
            if (pIpForwardTable->table[i].dwForwardDest == 0) {
                struct in_addr addr;
                addr.S_un.S_addr = pIpForwardTable->table[i].dwForwardNextHop;
                char temp[64];
                snprintf(temp, sizeof(temp), "%d.%d.%d.%d",
                    addr.S_un.S_un_b.s_b1, addr.S_un.S_un_b.s_b2,
                    addr.S_un.S_un_b.s_b3, addr.S_un.S_un_b.s_b4);
                if (is_private_ip(temp)) {
                    strncpy(ip, temp, size - 1);
                    ip[size - 1] = '\0';
                    found = 1;
                    break;
                }
            }
        }
    }

    free(pIpForwardTable);
    return found;
}

int detect_router_ip(char *ip, size_t size)
{
    char temp[64];

    if (get_default_gateway(temp, sizeof(temp))) {
        strncpy(ip, temp, size - 1);
        ip[size - 1] = '\0';
        return 1;
    }

    return 0;
}

/* ================================================== */
/* SSH key authentication                             */
/* ================================================== */
int file_exists(const char *path)
{
    DWORD attr = GetFileAttributesA(path);
    return (attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY));
}

void get_key_paths(const char *ip, char *priv, char *pub, char *ssh_dir, size_t size)
{
    char userprofile[512] = {0};
    char key_name[256] = {0};
    char ip_safe[256] = {0};
    const char *p;
    char *q;
    
    /* IPアドレスのドットをアンダースコアに置き換え */
    for (p = ip, q = ip_safe; *p && (q - ip_safe < sizeof(ip_safe) - 1); p++) {
        *q++ = (*p == '.') ? '_' : *p;
    }
    *q = '\0';
    
    /* 鍵名を生成: aios2_<IP>_rsa */
    snprintf(key_name, sizeof(key_name), "aios2_%s_rsa", ip_safe);
    
    GetEnvironmentVariableA("USERPROFILE", userprofile, sizeof(userprofile));
    snprintf(ssh_dir, size, "%s\\.ssh", userprofile);
    snprintf(priv, size, "%s\\%s", ssh_dir, key_name);
    snprintf(pub, size, "%s\\%s.pub", ssh_dir, key_name);
}

int ensure_ssh_key(const char *sysroot, const char *key_path, const char *ssh_dir)
{
    char cmd[2048];

    if (file_exists(key_path)) return 1;

    CreateDirectoryA(ssh_dir, NULL);

    printf("Generating SSH key...\n");
    snprintf(cmd, sizeof(cmd),
        "%s\\System32\\OpenSSH\\ssh-keygen.exe -t rsa -N \"\" -f \"%s\"",
        sysroot, key_path);

    return (system(cmd) == 0);
}

int test_key_auth(const char *sysroot, const char *key_path, const char *ip)
{
    char cmd[2048];

    snprintf(cmd, sizeof(cmd),
        "%s\\System32\\OpenSSH\\ssh.exe"
        SSH_OPTS
        " -o BatchMode=yes"
        " -o ConnectTimeout=5"
        " -i \"%s\""
        " root@%s exit",
        sysroot, key_path, ip);

    return (system(cmd) == 0);
}

int send_public_key(const char *sysroot, const char *pub_path, const char *ip)
{
    char cmd[2048];

    printf("Registering public key (password required once)...\n\n");
    snprintf(cmd, sizeof(cmd),
        "type \"%s\" | %s\\System32\\OpenSSH\\ssh.exe"
        SSH_OPTS
        " root@%s"
        " \"cat >> /etc/dropbear/authorized_keys"
        " && chmod 600 /etc/dropbear/authorized_keys\"",
        pub_path, sysroot, ip);

    return (system(cmd) == 0);
}

/* ================================================== */
/* Installer scripts                                  */
/* ================================================== */
const char* get_aios2_installer(void)
{
    return
        "cat << 'EOF' > /usr/bin/aios2\n"
        "#!/bin/sh\n"
        "CONFIG_DIR=\"/tmp/aios2\"\n"
        "mkdir -p \"$CONFIG_DIR\"\n"
        "CACHE_BUSTER=\"?t=$(date +%s)\"\n"
        "wget --no-check-certificate -O \"$CONFIG_DIR/aios2.sh\" \"https://site-u.pages.dev/www/aios2.sh${CACHE_BUSTER}\"\n"
        "chmod +x \"$CONFIG_DIR/aios2.sh\"\n"
        "sh \"$CONFIG_DIR/aios2.sh\" \"$@\"\n"
        "EOF\n"
        "chmod +x /usr/bin/aios2";
}

const char* get_aios_installer(void)
{
    return
        "cat << 'EOF' > /usr/bin/aios\n"
        "#!/bin/sh\n"
        "BASE_DIR=\"/tmp/aios\"\n"
        "BASE_FILE=\"aios.sh\"\n"
        "BASE_PATH=\"$BASE_DIR/$BASE_FILE\"\n"
        "BASE_URL=\"https://raw.githubusercontent.com/site-u2023/aios/main/$BASE_FILE\"\n"
        "if [ ! -d \"$BASE_DIR\" ]; then\n"
        "    mkdir -p \"$BASE_DIR\"\n"
        "    if [ $? -ne 0 ]; then\n"
        "        echo \"Error: Failed to create base directory $BASE_DIR\" >&2\n"
        "        exit 1\n"
        "    fi\n"
        "fi\n"
        "if command -v wget >/dev/null 2>&1; then\n"
        "    cache_buster=$(date +%s)\n"
        "    download_url=\"$BASE_URL?cache_bust=$cache_buster\"\n"
        "    wget -q -O \"$BASE_PATH\" \"$download_url\"\n"
        "    download_status=$?\n"
        "    if [ $download_status -ne 0 ]; then\n"
        "        echo \"Error: Failed to download $BASE_FILE (wget exit code: $download_status)\" >&2\n"
        "        rm -f \"$BASE_PATH\"\n"
        "        exit 2\n"
        "    fi\n"
        "else\n"
        "    echo \"Error: wget command not found. Cannot download $BASE_FILE.\" >&2\n"
        "    exit 3\n"
        "fi\n"
        "chmod +x \"$BASE_PATH\"\n"
        "if [ $? -ne 0 ]; then\n"
        "    echo \"Error: Failed to make $BASE_PATH executable\" >&2\n"
        "    rm -f \"$BASE_PATH\"\n"
        "    exit 4\n"
        "fi\n"
        "exec \"$BASE_PATH\" \"$@\"\n"
        "exec_failed_status=$?\n"
        "echo \"Error: Failed to execute $BASE_PATH (exit code: $exec_failed_status)\" >&2\n"
        "exit $exec_failed_status\n"
        "EOF\n"
        "chmod +x /usr/bin/aios";
}

/* ================================================== */
/* Main                                               */
/* ================================================== */
int main(int argc, char *argv[])
{
    const char *command = (argc > 1) ? argv[1] : NULL;
    char ip[256] = {0};
    char input[256] = {0};
    char cmd[4096];
    char sysroot[512] = {0};
    char key_path[512] = {0};
    char pub_path[512] = {0};
    char ssh_dir[512] = {0};
    int use_key = 0;
    int is_command = 0;

    GetEnvironmentVariableA("SYSTEMROOT", sysroot, sizeof(sysroot));

    /* Check if argument is command */
    if (command) {
        if (strcmp(command, "aios2") == 0 || strcmp(command, "aios") == 0) {
            is_command = 1;
        }
    }

    /* Banner */
    printf("========================================\n");
    if (is_command) {
        printf("aios2 - Remote Command Execution\n");
    } else {
        printf("aios2 - SSH Connection\n");
    }
    printf("========================================\n\n");

    /* IP detection */
    if (!detect_router_ip(ip, sizeof(ip))) {
        strcpy(ip, DEFAULT_IP);
    }

    printf("Enter OpenWrt IP address [%s]: ", ip);
    fflush(stdout);
    if (fgets(input, sizeof(input), stdin)) {
        input[strcspn(input, "\r\n")] = '\0';
        if (input[0] != '\0') {
            strncpy(ip, input, sizeof(ip) - 1);
            ip[sizeof(ip) - 1] = '\0';
        }
    }

    /* Generate key paths based on IP address */
    get_key_paths(ip, key_path, pub_path, ssh_dir, sizeof(key_path));

    /* Key authentication setup */
    if (ensure_ssh_key(sysroot, key_path, ssh_dir)) {
        if (test_key_auth(sysroot, key_path, ip)) {
            use_key = 1;
        } else {
            if (send_public_key(sysroot, pub_path, ip)) {
                use_key = 1;
            }
        }
    }

    /* Build main command */
    if (is_command) {
        printf("\nTarget: %s\n", ip);
        printf("Command: %s\n\n", command);
        printf("Connecting and executing command...\n\n");

        if (strcmp(command, "aios2") == 0) {
            if (use_key) {
                snprintf(cmd, sizeof(cmd),
                    "%s\\System32\\OpenSSH\\ssh.exe"
                    SSH_OPTS
                    " -i \"%s\""
                    " -tt root@%s"
                    " \"command -v aios2 >/dev/null 2>&1 || (%s); aios2\"",
                    sysroot, key_path, ip, get_aios2_installer());
            } else {
                snprintf(cmd, sizeof(cmd),
                    "%s\\System32\\OpenSSH\\ssh.exe"
                    SSH_OPTS
                    " -tt root@%s"
                    " \"command -v aios2 >/dev/null 2>&1 || (%s); aios2\"",
                    sysroot, ip, get_aios2_installer());
            }
        } else if (strcmp(command, "aios") == 0) {
            if (use_key) {
                snprintf(cmd, sizeof(cmd),
                    "%s\\System32\\OpenSSH\\ssh.exe"
                    SSH_OPTS
                    " -i \"%s\""
                    " -tt root@%s"
                    " \"command -v aios >/dev/null 2>&1 || (%s); aios\"",
                    sysroot, key_path, ip, get_aios_installer());
            } else {
                snprintf(cmd, sizeof(cmd),
                    "%s\\System32\\OpenSSH\\ssh.exe"
                    SSH_OPTS
                    " -tt root@%s"
                    " \"command -v aios >/dev/null 2>&1 || (%s); aios\"",
                    sysroot, ip, get_aios_installer());
            }
        }
    } else {
        printf("\nTarget: root@%s\n\n", ip);
        printf("Connecting...\n\n");

        if (use_key) {
            snprintf(cmd, sizeof(cmd),
                "%s\\System32\\OpenSSH\\ssh.exe"
                SSH_OPTS
                " -i \"%s\""
                " -tt root@%s",
                sysroot, key_path, ip);
        } else {
            snprintf(cmd, sizeof(cmd),
                "%s\\System32\\OpenSSH\\ssh.exe"
                SSH_OPTS
                " -tt root@%s",
                sysroot, ip);
        }
    }

    int ret = system(cmd);

    if (is_command) {
        if (ret == 0) {
            printf("\n========================================\n");
            printf("Completed successfully\n");
            printf("========================================\n");
        } else {
            printf("\n========================================\n");
            printf("Failed - Please check the error messages\n");
            printf("========================================\n");
        }
    }

    printf("\n");
    system("pause");
    return 0;
}
